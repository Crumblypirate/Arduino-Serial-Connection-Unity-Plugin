#include "Plug.h"


//constructor
Plugin::Plugin()
{
}

int Plugin::SearchForArduino()
{
	//count devices
	int count = 0;

	//object seracher attached to location of com ports
		ManagementObjectSearcher^ search = gcnew ManagementObjectSearcher("root\\CIMV2",
		"SELECT * FROM Win32_PnPEntity WHERE ClassGuid=\"{4d36e978-e325-11ce-bfc1-08002be10318}\"");

	//cycle through found com ports
	for each (ManagementObject^ cP in search->Get())
	{
		//get the description from each found device
		String^ tempString = cP["Description"]->ToString();
		std::string portDesc = msclr::interop::marshal_as<std::string>(tempString);

		//search description for arduino name or CH340 (Arduino NANO) **Add to when more descriptions can be identified**
		if ((portDesc.find("Arduino") != std::string::npos) || (portDesc.find("CH340") != std::string::npos))
		{
			//find com port number of the found arduinos
			String^ tempString2 = cP["Name"]->ToString();
			std::string portDesc2 = msclr::interop::marshal_as<std::string>(tempString2);

			//when found copm port number erase uneeded characters and store in array
			if (portDesc2.find("COM") != std::string::npos)
			{
				std::size_t pos;
				std::size_t pos2;

				pos = portDesc2.find('(');

				pos2 = portDesc2.find(')');

				portDesc2.erase(pos2, pos2 + 1);
				portDesc2.erase(0, pos + 1);

				int numLen = portDesc2.length() - 3;
				std::string comNumStr = portDesc2.substr(portDesc2.length() - numLen, numLen);
				int comNum = std::stoi(comNumStr, nullptr, 10);

				foundArr[count] = comNum;
				count++;
			}
		}
	}
	// return amount of deivecs found
	return count;
}


void Plugin::Connect(int ArdNo)
{
	try
	{
		//call search for arduino function to populate array
		int devFound = SearchForArduino();
		String^ comPort;
		int cPort;

		//use number passed from user to find the correct com port number in the array
		cPort = foundArr[ArdNo - 1];

		//create new instance of serialport
		sP = gcnew SerialPort;

		//set up port settings
		sP->PortName = "COM" + cPort.ToString();
		sP->BaudRate = 9600;
		sP->DtrEnable = false;

		//open port
		sP->Open();

		//set read and write timeouts
		sP->ReadTimeout = 1;
		sP->WriteTimeout = 1;
	}
	catch(Exception^ e)
	{ }
}

bool Plugin::ConTest()
{
	//simple test to see if the com port is connected
	if (sP->IsOpen)
	{		
		return true;
	}
	else
		return false;
}

//close the connection for the com port passed in by the user
void Plugin::TerminateConnection()
{
	if (sP->IsOpen)
	{
		sP->Close();		
	}
}


void Plugin::WriteToSerial(const char* inc)
{
	//check if com port is open
	if (sP->IsOpen)
	{
		//make sure somthing was passed
		if (inc != NULL)
		{
			//marshal the char pointer to a system string
			String^ hh = msclr::interop::marshal_as<String^>(inc);

			//convert string to upper case characters then write to serial
			sP->Write(hh->ToUpper());

			//make sure everthing is written and clear buffer.
			sP->BaseStream->Flush();
		}
	}
}

BSTR Plugin::ReadSerial()
{

	String^ temp;
	std::string str;
	
	//make sure buffer is clear before read
	sP->BaseStream->Flush();
	
	try
	{	
		//read latest line in serial connection
		temp = sP->ReadLine();
		
		//clear and discard buffer.
		sP->BaseStream->Flush();
		sP->DiscardInBuffer();
		
		//marshal recieved system string to c++ string
		str = msclr::interop::marshal_as<std::string>(temp);
	
		//return string
		return ::SysAllocString(CComBSTR(str.c_str()).Detach());
	
	}
	catch (Exception^ e)
	{
	}
}

//write identify to serial, will prompt arduino to flash onboard LED, will not work usless using included sketch
void Plugin::Identify()
{
	if (sP->IsOpen)
	{
		WriteToSerial("identify");
	}
}

//set a given pin to input or output, will not work usless using included sketch
void Plugin::SetPin(int pin, const char * inorout)
{
	//make sure connection is open
	if (sP->IsOpen)
	{
		//check if passed ion valuse are not NULL
		if (pin != NULL && inorout != NULL)
		{
			//marshal the char* to a system string
			String^ hh = msclr::interop::marshal_as<String^>(inorout);

			//convert string to uppercase and write pin and string to serial
			sP->Write(pin + ":" + hh->ToUpper());

			//clear buffer
			sP->BaseStream->Flush();
		}
	}
}

//control a given pin turning it on (HIGH) or off (LOW), will not work usless using included sketch
void Plugin::ControlPin(int pin, int level)
{
	//check if connection is open
	if (sP->IsOpen)
	{
		//make sure passed in valuse are not empty
		if (pin != NULL)
		{
			//write vlaues to serial
			sP->Write(pin + "-" + level);

			//clear buffer
			sP->BaseStream->Flush();
		}
	}
}

//get the state of a given pin, will not work usless using included sketch
bool Plugin::GetPinState(int pin)
{
	
	String^ pinState;
	bool con1 = false;
	bool con2 = false;

	//check if connection is open
	if (sP->IsOpen)
	{
		//check if passed in values are not empty
		if (pin != NULL)
		{
		
			//write pin to serial
			sP->Write("L" + "/" + pin);

			//clear buffer
			sP->BaseStream->Flush();
		}

		try
		{
			//read recieved line
			pinState = sP->ReadLine();

			//take string and see if it contains 0 or 1
			con1 = pinState->Contains("0");
			con2 = pinState->Contains("1");

			//return true or false depending if the pin is HIGH or LOW
			if (con1 == true || con2 == true)
			{
				if (con1)
				{
					return false;
				}

				if (con2)
				{
					return true;
				}
				
			}else pinState = sP->ReadLine();
		}
		catch (Exception^ e)
		{

		}
	}
}

//deconstructor
Plugin::~Plugin()
{
}

