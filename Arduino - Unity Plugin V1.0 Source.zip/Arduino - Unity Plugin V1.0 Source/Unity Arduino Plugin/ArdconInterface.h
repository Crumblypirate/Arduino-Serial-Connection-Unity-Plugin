class IArdcon
{


public:

	virtual void connect() = 0;
	virtual bool isConnected() = 0;



};