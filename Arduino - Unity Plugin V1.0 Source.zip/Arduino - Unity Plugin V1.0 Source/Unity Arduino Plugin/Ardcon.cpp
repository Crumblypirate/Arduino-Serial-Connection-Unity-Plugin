#include  "Ardcon.h"


Ardcon::Ardcon()
{

}


	void Ardcon::connect()
	{
		sp = gcnew SerialPort;

		sp->PortName = "COM3";


		sp->BaudRate = 9600;

		sp->Open();

	}

	bool Ardcon::isConnected()
	{
		if (sp->IsOpen)
		{
			return true;
		}
		else
			return false;
	}


