#pragma once
#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>
#include <vector>
#include <msclr/marshal_cppstd.h>
#include <atlbase.h>
#include <ctime>

#using <System.dll>
#using <System.Management.dll>

using namespace System;
using namespace System::IO::Ports;
using namespace System::ComponentModel;
using namespace System::Management;
using namespace System::Threading;
using namespace System::Runtime::InteropServices;


class __declspec(dllimport) Plugin
{

	//global serial port vairable
	gcroot<SerialPort^> sP;

	//array storing com port number of connected arduinos found
	int foundArr[10];

public:
	Plugin();
	int SearchForArduino();
	void Connect(int ArdNo);
	bool ConTest();
	void TerminateConnection();
	void WriteToSerial(const char* inc);
	BSTR __stdcall ReadSerial();
	void Identify();
	void SetPin(int pin, const char* inorout);
	void ControlPin(int pin, int level);
	bool GetPinState(int pin);
	~Plugin();
};
