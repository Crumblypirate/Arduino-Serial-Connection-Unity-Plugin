#include <cstring>
#include <string>
#include <algorithm>
#include <iostream>
#include <vector>
#include <msclr/marshal_cppstd.h>
#include <atlbase.h>
#include <ctime>
#include "Plug.h"

#using <System.dll>
#using <System.Management.dll>

using namespace System;
using namespace System::IO::Ports;
using namespace System::ComponentModel;
using namespace System::Management;
using namespace System::Threading;
using namespace System::Runtime::InteropServices;

//allows unity to access methods
#define DllExport __declspec (dllexport)

extern "C"
{

//create a new instance of the plugin class
DllExport Plugin* Create()
{
	return new Plugin();
}

//call connect function of the plugin class
DllExport void Connectf(Plugin* pObject, int ArdNo)
{

	pObject->Connect(ArdNo);
	
}

//call connection test function of the plugin class
DllExport bool ConTest(Plugin* pObject)
{

	return pObject->ConTest();
	
}

//call terminate connection function of the plugin class
DllExport void TerminateConnection(Plugin* pObject)
{

	pObject->TerminateConnection();

}

//call write to serial function of the plugin class
DllExport void WriteToSerial(Plugin* pObject, const char* inc)
{

	pObject->WriteToSerial(inc);

}

//call read serial function of the plugin class
DllExport BSTR __stdcall ReadSerial(Plugin* pObject)
{

	return pObject->ReadSerial();

}

//call identify function of the plugin class
DllExport void Identify(Plugin* pObject)
{

	return pObject->Identify();

}

//call setpin function of the plugin class
DllExport void SetPin(Plugin* pObject, int pin, const char* inorout)
{

	return pObject->SetPin(pin, inorout);

}

//call control pin function of the plugin class
DllExport void ControlPin(Plugin* pObject, int pin, int level)
{

	return pObject->ControlPin(pin, level);

}

//call getpinstate function of the plugin class
DllExport bool GetPinState(Plugin* pObject, int pin)
{

	return pObject->GetPinState(pin);

}

}
