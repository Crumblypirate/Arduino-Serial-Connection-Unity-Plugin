#include "ArdconInterface.h"

#include <string>
#include <algorithm>
#include <iostream>
#include <vector>
#include <msclr/marshal_cppstd.h>
#include <vcclr.h>  

#using <System.dll>
#using <System.Management.dll>

using namespace System;
using namespace System::IO::Ports;
using namespace System::ComponentModel;
using namespace System::Management;
using namespace System::Threading;

class Ardcon : public IArdcon
{

public:
	
	Ardcon();
	void connect();
	bool isConnected();

	gcroot<SerialPort^> sp;


};