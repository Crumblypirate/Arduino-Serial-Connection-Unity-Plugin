﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

using System.Runtime.InteropServices;

public class ri : MonoBehaviour {

	[DllImport("Unity Arduino Plugin")]
	private static extern IntPtr Create ();

	[DllImport("Unity Arduino Plugin")]
	private static extern void Connectf (IntPtr pClassName, int i);

	[DllImport("Unity Arduino Plugin")]
	private static extern bool ConTest (IntPtr pClassName);

    [DllImport("Unity Arduino Plugin")]
    private static extern void TerminateConnection(IntPtr pClassName);

    [DllImport("Unity Arduino Plugin")]
    private static extern void WriteToSerial(IntPtr pClassName, string send);

    [DllImport("Unity Arduino Plugin", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    [return: MarshalAs(UnmanagedType.BStr)]
    private static extern string ReadSerial(IntPtr pClassName);

    [DllImport("Unity Arduino Plugin")]
    private static extern void Identify(IntPtr pClassName);

    [DllImport("Unity Arduino Plugin")]
    private static extern void SetPin(IntPtr pObject, int pin, string inorout);

    [DllImport("Unity Arduino Plugin")]
    private static extern void ControlPin(IntPtr pObject, int pin, int level);

	[DllImport("Unity Arduino Plugin")]
	private static extern bool GetPinState(IntPtr pObject, int pin);

    bool meh = false;
	string reading;
	string pinstate;
	bool gh = false;

    //declare intger pointers to use as a reference for each com port connection.
	IntPtr com, com2;

    void Start () {

        //call create and assign to each intger pointer, creates a new instance of the class, esentially a new serial port connection
        com = Create();
        com2 = Create();
	
        //connect requires the instance of the class and an intger to be assigned to it, HAS TO BE 1, 2, 3, 4, ECT DEPENDING ON HOW MANY ARDUINOS ARE CONNECTED.
        //a connection will then be attempted with all arduinos connected to the computer
        Connectf(com, 1);
        Connectf(com2, 2);

    }
    
	
	// Update is called once per frame
	void Update () {


        //using get key down for demo purposes to display individual operation
		if (Input.GetKeyDown (KeyCode.C)) {

           //terminate connection requires the reference to the serial connection desired and will close that connection
            TerminateConnection(com);
            TerminateConnection(com2);

        }

        
		if (Input.GetKeyDown (KeyCode.O)) {

            //test connection requires the reference to the desired serial connection and will return true or false depending if the arduino is connected or not
            meh = ConTest (com);
			Debug.Log (meh);

            meh = ConTest(com2);
            Debug.Log(meh);

        }

        
		if (Input.GetKeyDown (KeyCode.D)) {

            //write to serial will requires reference to the serial connection and takes a string argumnet which will be written to the serial connection
			WriteToSerial (com, "1");

		}

        if (Input.GetKeyDown(KeyCode.X))
        {
            //write to serial will requires reference to the serial connection and takes a string argumnet which will be written to the serial connection
            WriteToSerial(com2, "MEH");

        }

        if (Input.GetKeyDown (KeyCode.K)) {

            //readserial requires reference to the serial connection will read the most recent line in the serial connection
            reading = ReadSerial(com);
            Debug.Log(reading);

		}


        if (Input.GetKeyDown(KeyCode.V))
        {

            //identify requires reference to the serial connection , providing user is using specified arduino sketch, will send a send a string to arduino making the onboard LED blink
            //main used to identify which arduino the user is targeting after assiging com,1 /com,2 ect, 
            //ONLY WORKS IF USING INCLUDED ARDUINO SKETCH
            Identify(com);

        }


        if (Input.GetKeyDown(KeyCode.L))
        {
            //setpin, requires reference to the serial connection, an integer value representing the pin number and a string value representing if the pin is an input or an output,
            //this sets the pin mode in the arduino sketch and should ideally be used before control pin to avoid frying boards
            //ONLY WORKS IF USING INCLUDED ARDUINO SKETCH
            SetPin(com, 3, "output");

        }

        if (Input.GetKeyDown(KeyCode.I))
        {
            //control pin, requires reference to the serial connection, and 2 intger values, the 1st represents the digital pin number on the arduino board the 2nd value should be 0 or 1 this
            //represents a high or low setting for that pin
            //ONLY WORKS IF USING INCLUDED ARDUINO SKETCH
            ControlPin(com, 3, 1);
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            //control pin, requires reference to the serial connection, and 2 intger values, the 1st represents the digital pin number on the arduino board the 2nd value should be 0 or 1 this
            //represents a high or low setting for that pin
            ControlPin(com, 3, 0);
        }

		if (Input.GetKeyDown(KeyCode.A))
		{
            //get pin state, requires reference to the serial connection, and an intger value which will return true or false depending on the current state of the declared pin
            //e.g. if pin is HIGH (being used), return true if pin is LOW (not used) return false.
            //ONLY WORKS IF USING INCLUDED ARDUINO SKETCH
            gh = GetPinState(com, 3);
			Debug.Log ("PINSTATE" + gh);

		}


    }



}
